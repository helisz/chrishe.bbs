var gulp = require('flarum-gulp');

gulp({
  modules: {
    'sticky': 'src/**/*.js'
  }
});

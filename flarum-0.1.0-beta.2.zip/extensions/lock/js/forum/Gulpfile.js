var gulp = require('flarum-gulp');

gulp({
  modules: {
    'lock': 'src/**/*.js'
  }
});

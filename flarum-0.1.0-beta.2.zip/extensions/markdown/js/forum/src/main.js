import { extend } from 'flarum/extend';
import app from 'flarum/app';

app.initializers.add('markdown', function() {
  // TODO
});

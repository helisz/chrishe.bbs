import { extend } from 'flarum/extend';
import app from 'flarum/app';

app.initializers.add('bbcode', function() {
  // TODO
});

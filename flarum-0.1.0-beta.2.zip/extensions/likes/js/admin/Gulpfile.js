var gulp = require('flarum-gulp');

gulp({
  modules: {
    'likes': 'src/**/*.js'
  }
});

var gulp = require('flarum-gulp');

gulp({
  modules: {
    'bbcode': 'src/**/*.js'
  }
});

var gulp = require('flarum-gulp');

gulp({
  modules: {
    'suspend': 'src/**/*.js'
  }
});

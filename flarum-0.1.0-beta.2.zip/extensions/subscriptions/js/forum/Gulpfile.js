var gulp = require('flarum-gulp');

gulp({
  modules: {
    'subscriptions': 'src/**/*.js'
  }
});
